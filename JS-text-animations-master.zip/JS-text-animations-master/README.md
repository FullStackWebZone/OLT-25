# JS-text-animations

Page: https://dashinin.github.io/JS-text-animations/
