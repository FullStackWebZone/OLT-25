# LiquidBowlAnimation
Animation of one Potion just with CSS
