# Loading-Screen-Animation
Loading Screen Animation using HTML &amp; CSS
